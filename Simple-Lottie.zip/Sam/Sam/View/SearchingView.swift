//
//  SearchingView.swift
//  Sam
//
//  Created by Nafeez Ahmed on 18/12/22.
//

import SwiftUI

struct SearchingView: View {
    @State var ProfileItems: [ProfileModel] = [
       // .init(title: "Hello There", subTitle: "Sign in to start up",lottieView: .init(name:"Profile-boy",bundle: .main)) ,
        .init(title: "Searching", subTitle: "Kindly wait until we check",lottieView: .init(name:"Searching",bundle: .main))
    ]
    @State var toggle = false
    var body: some View {
        ZStack {
            ZStack {
                NavigationView {
                    GeometryReader {
                        let size = $0.size
                        HStack(spacing:0) {
                            ForEach($ProfileItems) {$item in
                                ZStack {
                                    Color("Green")
                                        .edgesIgnoringSafeArea(.all)
                                        .opacity(0.4)
                                    VStack {
                                        // Movable Slides
                                        ResizableLottieView(profileItems: $item)
                                            .frame(width:size.width,height: size.height/2.37)
                                            .onAppear {
                                                item.lottieView.play()
                                                    
                                            }
                                       Text("Searching..")
                                        
                                    }
                                    .padding(15)
                                    .frame(width:size.width,height: size.height)
                                }
                            }
                        }
                        .frame(width:size.width * CGFloat(ProfileItems.count),alignment: .leading)
                        .onAppear {
                            DispatchQueue.main.asyncAfter(deadline: .now() + 4, execute: {
                                toggle = true
                            })
                        }
                    }
                }
                .navigationBarBackButtonHidden(true)
            }
            if toggle {
                CheckMark()
            }
        }
     
        
    }
    struct ResizableLottieView: UIViewRepresentable {
        @Binding var profileItems: ProfileModel
        func makeUIView(context: Context) ->  UIView {
            let view = UIView()
            view.backgroundColor = .clear
            setUpLottieView(view)
            return view
        }
        func updateUIView(_ uiView: UIView, context: Context) {
            
        }
        
        func setUpLottieView(_ to: UIView) {
          
            let lottieView = profileItems.lottieView
            lottieView.backgroundColor = .clear
            lottieView.translatesAutoresizingMaskIntoConstraints = false
            
            // Adding Constraints
            let constraints = [
                lottieView.widthAnchor.constraint(equalTo: to.widthAnchor ),
                lottieView.heightAnchor.constraint(equalTo: to.heightAnchor)
            ]
            to.addSubview(lottieView)
            to.addConstraints(constraints)
        }
    }
}

struct SearchingView_Previews: PreviewProvider {
    static var previews: some View {
        SearchingView()
    }
}
