//
//  CheckMark.swift
//  Sam
//
//  Created by Nafeez Ahmed on 18/12/22.
//

import SwiftUI

struct CheckMark: View {
    @State var ProfileItems: [ProfileModel] = [
       // .init(title: "Hello There", subTitle: "Sign in to start up",lottieView: .init(name:"Profile-boy",bundle: .main)) ,
        .init(title: "Searching", subTitle: "Kindly wait until we check",lottieView: .init(name:"Check-mark",bundle: .main))
    ]
    var body: some View {
        NavigationView {
            GeometryReader {
                let size = $0.size
                HStack(spacing:0) {
                    ForEach($ProfileItems) {$item in
                        ZStack {
                            Color("Green")
                                .edgesIgnoringSafeArea(.all)
                                .opacity(0.4)
                            VStack {
                                // Movable Slides
                                ResizableLottieView(profileItems: $item)
                                    .frame(width:size.width,height: size.height/2.37)
                                    .onAppear {
                                        item.lottieView.play()
                                            
                                    }
                                
                                VStack {
                                    Text("Welcome Aboard")
                                        .font(.title)
                                        .foregroundColor(.black)
                                        .fontWeight(.bold)
                                    Text("Nafeez")
                                        .font(.largeTitle)
                                        .foregroundColor(.green)
                                        .fontWeight(.black)
                                }
                            }
                            .padding(15)
                            .frame(width:size.width,height: size.height)
                        }
                    }
                }
                .frame(width:size.width * CGFloat(ProfileItems.count),alignment: .leading)
            }
        }
        .navigationBarBackButtonHidden(true)
    }
    struct ResizableLottieView: UIViewRepresentable {
        @Binding var profileItems: ProfileModel
        func makeUIView(context: Context) ->  UIView {
            let view = UIView()
            view.backgroundColor = .clear
            setUpLottieView(view)
            return view
        }
        func updateUIView(_ uiView: UIView, context: Context) {
            
        }
        
        func setUpLottieView(_ to: UIView) {
          
            let lottieView = profileItems.lottieView
            lottieView.backgroundColor = .clear
            lottieView.translatesAutoresizingMaskIntoConstraints = false
            
            // Adding Constraints
            let constraints = [
                lottieView.widthAnchor.constraint(equalTo: to.widthAnchor ),
                lottieView.heightAnchor.constraint(equalTo: to.heightAnchor)
            ]
            to.addSubview(lottieView)
            to.addConstraints(constraints)
        }
    }
}

struct CheckMark_Previews: PreviewProvider {
    static var previews: some View {
        CheckMark()
    }
}
