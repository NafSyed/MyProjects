//
//  Profile.swift
//  Sam
//
//  Created by Nafeez Ahmed on 18/12/22.
//

import SwiftUI
import Lottie
struct Profile: View {
    @State var ProfileItems: [ProfileModel] = [
        .init(title: "Hello There", subTitle: "Sign in to start up",lottieView: .init(name:"Profile-boy",bundle: .main)) ,
        .init(title: "Searching", subTitle: "Kindly wait until we check",lottieView: .init(name:"Searching",bundle: .main))
    ]
    @State var textFiled: String = ""
    @State var password: String = ""
    @State var toggle: Bool = false
    var body: some View {
        NavigationView {
            GeometryReader {
                let size = $0.size
                HStack(spacing:0) {
                    ForEach($ProfileItems) {$item in
                        ZStack {
                            Color("Green")
                                .edgesIgnoringSafeArea(.all)
                                .opacity(0.4)
                            VStack {
                                // Movable Slides
                                ResizableLottieView(profileItems: $item)
                                    .frame(width:size.width,height: size.height/2.37)
                                    .onAppear {
                                        item.lottieView.play()
                                        DispatchQueue.main.asyncAfter(deadline: .now() + 9) {
                                            item.lottieView.pause()
                                        }
                                    }
                                VStack(spacing:20) {
                                    Text(item.title)
                                        .font(.title)
                                        .fontWeight(.black)
                                    TextField("Sign In", text: $textFiled)
                                        .padding()
                                        .background(Color.black.opacity(0.25))
                                        .clipShape(RoundedRectangle(cornerRadius: 30))
                                    SecureField("Password", text: $password)
                                        .padding()
                                        .background(Color.black.opacity(0.25))
                                        .clipShape(RoundedRectangle(cornerRadius: 30))
                                    
                                    NavigationLink(destination: SearchingView()) {
                                        Text("Sign In")
                                                .foregroundColor(.white)
                                                .fontWeight(.bold)
                                                .padding()
                                                .background(content: {
                                                    LinearGradient(gradient: Gradient(colors: [Color("Green"),.blue.opacity(0.3)]), startPoint: .topLeading, endPoint: .bottomTrailing)
                                                })
                                        
                                            .clipShape(RoundedRectangle(cornerRadius: 20))
                                    }
                                    .navigationBarBackButtonHidden(true)
                                    
                                   
                                }
                            }
                            .padding(15)
                            .frame(width:size.width,height: size.height)
                        }
                    }
                }
                .frame(width:size.width * CGFloat(ProfileItems.count),alignment: .leading)
            }
        }
    }
    struct ResizableLottieView: UIViewRepresentable {
        @Binding var profileItems: ProfileModel
        func makeUIView(context: Context) ->  UIView {
            let view = UIView()
            view.backgroundColor = .clear
            setUpLottieView(view)
            return view
        }
        func updateUIView(_ uiView: UIView, context: Context) {
            
        }
        
        func setUpLottieView(_ to: UIView) {
            let lottieView = profileItems.lottieView
            lottieView.backgroundColor = .clear
            lottieView.translatesAutoresizingMaskIntoConstraints = false
            
            // Adding Constraints
            let constraints = [
                lottieView.widthAnchor.constraint(equalTo: to.widthAnchor ),
                lottieView.heightAnchor.constraint(equalTo: to.heightAnchor)
            ]
            to.addSubview(lottieView)
            to.addConstraints(constraints)
        }
    }
}

struct Profile_Previews: PreviewProvider {
    static var previews: some View {
        Profile()
    }
}


