//
//  ProfileModel.swift
//  Sam
//
//  Created by Nafeez Ahmed on 18/12/22.
//

import SwiftUI
import Lottie

struct ProfileModel: Identifiable, Equatable {
    var id: UUID = .init()
    var title: String
    var subTitle: String
    var lottieView: LottieAnimationView = .init()
}
