//
//  SamApp.swift
//  Sam
//
//  Created by Nafeez Ahmed on 01/10/22.
//

import SwiftUI

@main
struct SamApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
