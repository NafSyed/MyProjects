//
//  WeatherWidgetLiveActivity.swift
//  Weather
//
//  Created by Nafeez Ahmed on 02/10/22.
//

import SwiftUI

import WidgetKit
import SwiftUI
import Intents
import ActivityKit

@main
struct WeatherWidgetLiveActivity: Widget {
    var body: some WidgetConfiguration {
        ActivityConfiguration(for: WeatherWidgetAttributes.self) {context in
            VStack(alignment: .leading) {
                HStack {
                    ZStack {
                        Rectangle()
                            .fill(Color(uiColor: .tertiarySystemFill))
                            .frame(width: 40, height: 40)
                        Image("weather-app")
                            .resizable()
                            .aspectRatio(1, contentMode: .fill)
                            .frame(width: 40, height: 40)
                    }
                    .clipShape(RoundedRectangle(cornerRadius: 8, style: .continuous))

                    Text(context.attributes.nextArticleName)
                        .lineLimit(2)
                        .font(.title3)
                        .bold()
                        .padding(8)
                }
                
                HStack{
                    Label {
                        Text("10m")
                            .multilineTextAlignment(.leading)
                            .monospacedDigit()
                            .bold()
                    } icon: {
                        Image(systemName: "clock")
                            .foregroundColor(.orange)
                    }
                    .font(.headline)
                    .padding(2)
                    .background(Color(uiColor: UIColor.secondarySystemFill))
                    .cornerRadius(4)
                    Label {
                        Text(timerInterval: context.state.timeTillNextReadingSession, countsDown: true)
                            .monospacedDigit()
                    } icon: {
                        Image(systemName: "timer")
                            .foregroundColor(.indigo)
                            .font(.headline)
                    }
                    .font(.headline)
                    .padding(2)
                    .background(Color(uiColor: UIColor.secondarySystemFill))
                    .cornerRadius(4)
                    .frame(width: 72)
                    Spacer()
                }
            }
            .clipShape(ContainerRelativeShape())
            .activityBackgroundTint(Color(UIColor.systemFill))
            .activitySystemActionForegroundColor(Color.orange)
            .padding()
        }dynamicIsland: { context in
            DynamicIsland {
                // Expanded UI goes here.  Compose the expanded UI through
                // various regions, like leading/trailing/center/bottom
                DynamicIslandExpandedRegion(.leading, priority: 2) {
                    Label {
                        Text("10m")
                            .multilineTextAlignment(.leading)
                            .monospacedDigit()
                            .bold()
                    } icon: {
                        Image(systemName: "clock")
                            .foregroundColor(.orange)
                    }
                    .font(.title2)
                }
                DynamicIslandExpandedRegion(.trailing, priority: 2) {
                    Label {
                        Text(timerInterval: context.state.timeTillNextReadingSession, countsDown: true)
                            .multilineTextAlignment(.trailing)
                            .frame(width: 50)
                            .monospacedDigit()
                            .bold()
                    } icon: {
                        Image(systemName: "timer")
                            .foregroundColor(.orange)
                    }
                    .font(.title2)
                }
                DynamicIslandExpandedRegion(.center, priority: 1) {
                    Text("Weather News")
                        .font(.headline)
                        .frame(maxWidth: .infinity)
                }
                DynamicIslandExpandedRegion(.bottom, priority: 0) {
                    Text(context.attributes.nextArticleName.prefix(35))
                        .font(.title2)
                        .frame(maxWidth: .infinity)
                }
                
            } compactLeading: {
                Image(systemName: "book")
                    .foregroundColor(.orange)
                    .font(.title2)
            } compactTrailing: {
                Image(systemName: "timer")
                    .foregroundColor(.orange)
                    .font(.title2)
            } minimal: {
                ProgressView(timerInterval: context.state.timeTillNextReadingSession, countsDown: true)
                    .progressViewStyle(CircularProgressViewStyle(tint: .orange))
                    .frame(width:20, height:20)
                    .fixedSize()
            }
            .widgetURL(URL(string: "http://www.apple.com"))
            .keylineTint(Color.red)
        }
    }
}
