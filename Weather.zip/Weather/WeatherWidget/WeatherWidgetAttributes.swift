//
//  WeatherWidgetAttributes.swift
//  Weather
//
//  Created by Nafeez Ahmed on 02/10/22.
//

import SwiftUI
import ActivityKit
struct WeatherWidgetAttributes: ActivityAttributes {
    public struct ContentState: Codable,Hashable {
        public var timeTillNextReadingSession: ClosedRange<Date>
    }
    public var nextArticleName: String
    public var nextArticleDescription: String
    public var nextArticleImage: URL
}


