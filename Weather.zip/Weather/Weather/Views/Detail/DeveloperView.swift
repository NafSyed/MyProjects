//
//  DeveloperView.swift
//  Weather
//
//  Created by Nafeez Ahmed on 14/08/22.
//

import SwiftUI

struct DeveloperView: View {
    var body: some View {
        ZStack {
            Color.background
                .ignoresSafeArea()
            ScrollView {
                VStack(spacing:20) {
                    ZStack {
                        Circle()
                            .stroke(.primary, lineWidth: 1)
                            .frame(width:340,height: 240)
                            .blendMode(.overlay)
                            .overlay {
                                Circle()
                                    .stroke(.primary, lineWidth: 1)
                                    .blendMode(.overlay)
                        }
                        Image("Developer")
                            .resizable()
                            .scaledToFill()
                            .frame(width:250,height: 200)
                            .clipShape(Circle())
                            
                       
                    }
                    .padding()
                    VStack(spacing:3) {
                        Text("Nafeez Ahmed")
                            .font(.largeTitle).fontWeight(.bold)
                            .foregroundColor(.primary)
                        Text("iOS Developer | Enthusiast")
                        
                    }
                    Text("The application of weather is fully developed and implemented in SwiftUI with so much experimentation and learning. Design alterations and extra features are added by the developer himself. Copyrights of the design belongs to Design+Code.")
                        .font(.title3).fontWeight(.medium)
                        .multilineTextAlignment(.center)
                        .foregroundColor(.primary)
                        .padding()
                    Text("DEVELOPER INFO")
                        .font(.title)
                        .foregroundColor(.secondary)
                    
                    VStack(spacing:10) {
                        Link(destination:URL(string: "https://www.twitter.com/Naf_Syed")!) {
                            
                            HStack {
                                Text("Twitter")
                                    .foregroundColor(.primary)
                                Spacer()
                                Image(systemName: "chevron.right")
                                    .foregroundColor(.gray)
                            }
                          
                            .frame(width:350,height: 20)
                            .padding()
                            .background(RoundedRectangle(cornerRadius: 30).fill(.black).opacity(0.2))
                           
                        }
                        Link(destination:URL(string: "https://www.instagram.com/naf_syed")!) {
                            
                            HStack {
                                Text("Instagram")
                                    .foregroundColor(.primary)
                                Spacer()
                                Image(systemName: "chevron.right")
                                    .foregroundColor(.gray)
                            }
                          
                            .frame(width:350,height: 20)
                            .padding()
                            .background(RoundedRectangle(cornerRadius: 30).fill(.black).opacity(0.2))
                           
                        }
                    }
                }
              
                
                    
            }
            
        }
    }
}

struct DeveloperView_Previews: PreviewProvider {
    static var previews: some View {
        DeveloperView()
            .preferredColorScheme(.dark)
    }
}
