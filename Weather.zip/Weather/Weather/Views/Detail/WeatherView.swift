//
//  WeatherView.swift
//  Weather
//
//  Created by Nafeez Ahmed on 14/08/22.
//

import SwiftUI

struct WeatherView: View {
    @State var searchText: String = ""
    @State var isShowingSheet = false
    
    var searchResults: [Forecast] {
        if searchText.isEmpty {
            return Forecast.cities
        }else {
            return Forecast.cities.filter{$0.location.contains(searchText)}
        }
    }
    var body: some View {
        ZStack {
            Color.background
                .ignoresSafeArea()
            ScrollView {
                VStack(spacing:20) {
                    ForEach(searchResults) {forecast in
                        WeatherWidget(forecast: forecast)
                    }
                }
            }
            .safeAreaInset(edge: .top, content: {
                EmptyView()
                    .frame(height:110)
            })
        }
        .sheet(isPresented: $isShowingSheet, content: {
            DeveloperView()
        })
       
        .overlay(content: {
            NavigationBar( searchText: $searchText, showingSheet: $isShowingSheet)
        })
        .navigationBarHidden(true)
       // .searchable(text: $searchText, placement: .navigationBarDrawer(displayMode: .automatic),prompt: "Search for a city")
       
    }
}

struct WeatherView_Previews: PreviewProvider {
    static var previews: some View {
        NavigationView {
            WeatherView()
                .preferredColorScheme(.dark)
        }
    }
}
