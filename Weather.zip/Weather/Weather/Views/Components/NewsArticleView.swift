//
//  NewsArticleView.swift
//  Weather
//
//  Created by Nafeez Ahmed on 31/08/22.
//

import SwiftUI
import CachedAsyncImage
struct NewsArticleView: View {
    var article: Article
    var body: some View {
        NavigationView {
            VStack(alignment:.leading) {
                ZStack {
                    VStack(alignment:.leading) {
                        Text(article.newsSite)
                            .font(.body)
                            .padding(.leading,10)
                            .padding(.top,10)
                            .foregroundColor(.primary).bold()
                        HStack(alignment: .center, content: {
                            CachedAsyncImage(url: URL(string: article.imageUrl),transaction:Transaction(animation: .easeInOut)) {phase in
                                if let image = phase.image {
                                    image
                                        .resizable()
                                        .scaledToFit()
                                        .clipShape(RoundedRectangle(cornerRadius: 20))
                                        .transition(.opacity)
                                }else {
                                    HStack {
                                        ProgressView()
                                    }
                                }
                            }
                        })
                        Text("\(article.title)")
                            .font(.callout)
                            .foregroundColor(.primary)
                            .padding(.leading,8)
                        Text(article.summary)
                            .font(.caption)
                            .lineLimit(3)
                            .font(.body)
                            .padding(8)
                    }
                    
                }
                .frame(width:300,height: 270)
                .clipShape(RoundedRectangle(cornerRadius: 30))
            
                
            }
        
        }
    }
}

struct NewsArticleView_Previews: PreviewProvider {
    static var previews: some View {
        NewsArticleView(article:artciles[0])
            .preferredColorScheme(.dark)
    }
}
