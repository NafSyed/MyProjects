//
//  ArticleView.swift
//  Weather
//
//  Created by Nafeez Ahmed on 31/08/22.
//

import SwiftUI
import ActivityKit
struct ArticleView: View {
    @Environment(\.presentationMode) var presentationMode: Binding<PresentationMode>
    @StateObject var data = API()
    @State private var opaque = 0.0
    @State  var article: Article?
    @Environment(\.openURL) var openURL
    var body: some View {
        NavigationView {
            ZStack {
                Color.background
                    .ignoresSafeArea()
                ScrollView {
                    VStack(spacing:20) {
                            ForEach(data.news) {news in
                                VStack(spacing:30) {
                                    NewsArticleView(article: news)
                                        .frame(width:365,height: 310)
                                        .clipShape(RoundedRectangle(cornerRadius: 30))
                                        .onTapGesture {
                                            article = news
                                        }
                                }
                            }
                        // to toggle the button to activate dynamic island
                            .contextMenu {
                                Button("Read in 2 min") {
                                    var future = Calendar.current.date(byAdding: .minute,value: 1, to: Date())!
                                    future = Calendar.current.date(byAdding: .second,value: 23, to: future)!
                                    let date = Date.now...future
                                    do {
                                        _ = try Activity.request(attributes: WeatherWidgetAttributes(nextArticleName: article?.title ?? "You have a news to read", nextArticleDescription: article?.summary ?? "there has been an error fetching summary", nextArticleImage: URL(string: "\(String(describing: article?.imageUrl))")!), contentState: WeatherWidgetAttributes.ContentState(timeTillNextReadingSession: date))
                                    }catch(let error) {
                                        print(error.localizedDescription)
                                    }
                                }
                            }
                        
                        .refreshable {
                            data.getData()
                    }
                    }
                    .environmentObject(data)
                }
            }
            .toolbar(content: {
                Button(action: {presentationMode.wrappedValue.dismiss()}, label: {
                    HStack {
                        Image(systemName: "chevron.left")
                            .font(.system(size: 23).weight(.medium))
                            .foregroundColor(.secondary)
                        Text("News")
                            .font(.title)
                            .foregroundColor(.primary)
                    }
                    .frame(height:44)
                })
                .frame(width:360,height:50,alignment: .leading)
                .padding(.horizontal,16)
                .padding(.top,49)
                .backgroundBlur(radius: 20,opaque: true)
                .background(Color.navBarBackground)
                .frame(maxHeight:.infinity,alignment: .top)
                .ignoresSafeArea()
            })
            .sheet(item: $article) {
                SafariView(url: URL(string: "\($0.url)")!)
            }
        }
       
       
        .navigationBarBackButtonHidden(true)
        //.navigationBarHidden(false)
        .onAppear {
            data.getData()
            withAnimation(.easeInOut(duration: 2)) {
                opaque = 1.0
            }
        }
  
        .frame(maxWidth:.infinity)
    }
}

struct ArticleView_Previews: PreviewProvider {
    static var previews: some View {
        ArticleView()
            .preferredColorScheme(.dark)
    }
}
