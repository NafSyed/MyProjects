//
//  IconView.swift
//  Weather
//
//  Created by Nafeez Ahmed on 15/08/22.
//

import SwiftUI

struct IconView: View {
    var forecast: Forecast
    var body: some View {
        ZStack {
           RoundedRectangle(cornerRadius: 30)
                .fill(LinearGradient(gradient: Gradient(colors: [Color.tabBarBorder,Color.forecastCardBackground,Color.probabilityText,Color.tabBarBorder,Color.purple,Color.primary]), startPoint: .topLeading, endPoint: .bottomTrailing))
                .frame(width:340,height: 240)
            Spacer()
            VStack(alignment:.trailing,spacing:0 ) {
                Image("\(forecast.icon) large")
                    .padding(.trailing,4)
                
            }
            .offset(x:100,y:-120)
        }
        
    }
}

struct IconView_Previews: PreviewProvider {
    static var previews: some View {
        IconView(forecast: Forecast.cities[0])
            .preferredColorScheme(.dark)
    }
}
