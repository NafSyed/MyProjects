//
//  WelcomeView.swift
//  Weather
//
//  Created by Nafeez Ahmed on 15/08/22.
//

import SwiftUI
import CoreLocationUI
struct WelcomeView: View {
    @State private var title: Bool = false
    @State private var isAnimating: Bool = true
    @State private var titleAnimation: Bool = false
    @State private var subheadLines: Bool = false
    @EnvironmentObject var locationManger: LocationManager
    var body: some View {
        ZStack {
            Color.background
                .edgesIgnoringSafeArea(.all)
            Image("Background")
                .resizable()
                .edgesIgnoringSafeArea(.all)
                .blur(radius: isAnimating ? 0 : 5)
                .onAppear {
                    DispatchQueue.main.asyncAfter(deadline: .now() + 0.3, execute: {
                        withAnimation(.linear(duration: 0.2)) {
                            isAnimating.toggle()
                        }
                       
                    })
                    
                    DispatchQueue.main.asyncAfter(deadline: .now() + 0.65, execute: {
                        withAnimation(.easeInOut(duration: 0.7)) {
                            title.toggle()
                        }
                    })
                    DispatchQueue.main.asyncAfter(deadline: .now() + 0.85, execute: {
                        withAnimation(.easeInOut) {
                            titleAnimation.toggle()
                        }
                    })
                    DispatchQueue.main.asyncAfter(deadline: .now() + 1.25, execute: {
                        withAnimation(.easeInOut(duration: 0.3)) {
                            subheadLines.toggle()
                        }
                    })
                }
            if title {
                VStack(spacing:20) {
                    VStack {
                        Text("Weather")
                            .font(.largeTitle)
                            .foregroundColor(.white)
                            .fontWeight(.heavy)
                            .opacity(title ? 1 : 0)
                    }
                    if subheadLines {
                        Text("Share your current location to know about the weather in your area.")
                            .font(.title3)
                            .foregroundColor(.white)
                            .multilineTextAlignment(.center)
                            .padding(.leading,10)
                            .padding(.trailing,10)
                    }
                    LocationButton(.shareCurrentLocation) {
                        let haptics = UIImpactFeedbackGenerator(style: .heavy)
                        haptics.impactOccurred()
                        locationManger.requestLocation()
                        
                    }
                    .cornerRadius(30)
                    .symbolVariant(.fill)
                    .foregroundColor(.white)
                }
                .frame(width:360,height: 300)
                .background(Color.background)
                .clipShape(RoundedRectangle(cornerRadius: 40))
               
            }
        }
    }
}

struct WelcomeView_Previews: PreviewProvider {
    static var previews: some View {
        WelcomeView()
    }
}
