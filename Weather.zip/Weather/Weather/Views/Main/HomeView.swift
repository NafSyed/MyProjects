//
//  HomeView.swift
//  Weather
//
//  Created by Nafeez Ahmed on 13/08/22.
//

import SwiftUI
import BottomSheet
import ActivityKit

enum BottomSheetPosition: CGFloat,CaseIterable {
    case top = 0.83
    case middle = 0.385
}
struct HomeView: View {
    @State var currentID: String = ""
    @State private var bottomSheetPosition: BottomSheetPosition = .middle
    @State var bottomSheetTranslation: CGFloat = BottomSheetPosition.middle.rawValue
    @State var hasDragged: Bool = false
    var bottomSheetTranslationProRated: CGFloat {
        (bottomSheetTranslation - BottomSheetPosition.middle.rawValue) / (BottomSheetPosition.top.rawValue - BottomSheetPosition.middle.rawValue)
    }
    var weather: ResponseBody
    var body: some View {
        NavigationView {
            GeometryReader { proxy in
                let screenHeight = proxy.size.height + proxy.safeAreaInsets.top + proxy.safeAreaInsets.bottom
                let imageOffset = screenHeight + 36
                ZStack {
                    Color.background
                        .edgesIgnoringSafeArea(.all)
                    Image("Background")
                        .resizable()
                        .edgesIgnoringSafeArea(.all)
                        .offset(y: -bottomSheetTranslationProRated * imageOffset - 10)
                    Image("House")
                        .scaledToFill()
                        .frame(maxHeight:.infinity,alignment: .top)
                        .padding(.top,257)
                        .offset(y:  -bottomSheetTranslationProRated * imageOffset )
                    
                    VStack(spacing:-10 * (1 - bottomSheetTranslationProRated)) {
                        Text(weather.name)
                            .font(.largeTitle)
                            .foregroundColor(.white)
                        VStack(alignment:.center) {
                            /*
                            Text("14°")
                                .font(.system(size: 96,weight: .thin))
                            Text("Partly Cloudy")
                                .font(.title3.weight(.semibold))
                                .foregroundColor(.secondary)
                             */
                            Text(attributedString)
                                .foregroundColor(.white)
                                .offset(x:15)
                            Text("H:\(weather.main.tempMax.roundDouble() + "°")    L:\(weather.main.tempMin.roundDouble())°")
                                .font(.title3.weight(.semibold))
                                .opacity(1 - bottomSheetTranslationProRated)
                                .foregroundColor(.white)
                        }
                      
                       
                        Spacer()
                    }
                    .padding(.top,51)
                    .offset(y: -bottomSheetTranslationProRated * 46)
                    
                    BottomSheetView(position: $bottomSheetPosition, header: {
                      //  Text(bottomSheetTranslationProRated.formatted())
                    }, content: {
                        ForecastView(bottomSheetTranslationProrated: bottomSheetTranslationProRated)
                    })
                    .onBottomSheetDrag(perform: { translation in
                        bottomSheetTranslation = translation / screenHeight
                        
                        withAnimation(.easeInOut) {
                            if bottomSheetPosition == BottomSheetPosition.top {
                                hasDragged = true
                            } else {
                                hasDragged = false
                            }
                        }
                        
                    })
                   
                    
                    TabBar(action: {bottomSheetPosition = .top})
                        .opacity(1)
                        .offset(y:hasDragged ? bottomSheetTranslationProRated * 115 : 0)
                        
                }
            }
            .navigationBarHidden(true)
            
        }
    }
    private var attributedString: AttributedString {
        var string = AttributedString("\(weather.main.feelsLike.roundDouble() + "°")" + (hasDragged ? " | " : "\n") + "\(weather.weather[0].description)")
        if let temp = string.range(of: "\(weather.main.feelsLike.roundDouble() + "°")") {
            string[temp].font = .system(size:hasDragged ? 20 : 96,weight:hasDragged ? .semibold : .thin)
            string[temp].foregroundColor = hasDragged ?.secondary : .primary
        }
        if let pipe = string.range(of: " | ") {
            string[pipe].font = .title3.weight(.semibold)
            string[pipe].foregroundColor = .secondary.opacity(bottomSheetTranslationProRated)
        }
        if let weather = string.range(of: "\(weather.weather[0].description)") {
            string[weather].font = .title3.weight(.semibold)
            string[weather].foregroundColor = .secondary
        }
        return string
    }
}

struct HomeView_Previews: PreviewProvider {
    static var previews: some View {
        HomeView(weather: previewWeather)
            .preferredColorScheme(.dark)
    }
}





