//
//  ContentView.swift
//  Weather
//
//  Created by Nafeez Ahmed on 13/08/22.
//

import SwiftUI

struct ContentView: View {
    @StateObject var locationManager = LocationManager()
    var weatherManager = WeatherManager()
    @State var weather: ResponseBody?
    var body: some View {
        ZStack {
            Color.primary
                .ignoresSafeArea()
            VStack {
                if let location = locationManager.location {
                    if let weather = weather {
                        HomeView(weather: weather)
                            .environmentObject(locationManager)
                            .frame(maxWidth:.infinity,maxHeight: .infinity)
                    }
                    else {
                        ZStack {
                            Color.background
                                .ignoresSafeArea()
                            ProgressView()
                                .task {
                                    do {
                                        weather = try await weatherManager.getCurrentWeather(latitude: location.latitude, longitude: location.longitude)
                                    }catch {
                                        print("Error getting weather \(error)")
                                    }
                                }
                        }

                    }
                }
                else {
                    if locationManager.isLoading {
                        ZStack {
                            Color.background
                                .ignoresSafeArea()
                            ProgressView()
                        }
                    }
                    else {
                        ZStack {
                            WelcomeView()
                                .environmentObject(locationManager)
                        }
                    }
                }
                
               
              
            }
        }
       
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
            .preferredColorScheme(.dark)
        
    }
}
