//
//  NavBar.swift
//  Weather
//
//  Created by Nafeez Ahmed on 31/08/22.
//

import SwiftUI

struct NavBar: View {
    @Environment(\.presentationMode) var presentationMode: Binding<PresentationMode>
    var body: some View {
        HStack {
            Button(action: {
                presentationMode.wrappedValue.dismiss()
            }, label: {
                HStack(spacing:5) {
                    Image(systemName: "chevron.left")
                        .font(.system(size: 23).weight(.medium))
                        .foregroundColor(.secondary)
                    Text("News")
                        .font(.title)
                        .foregroundColor(.primary)
                }
                
            })
            .frame(height:44)
        }
        .frame(width:360,height:50,alignment: .leading)
        .padding(.horizontal,16)
        .padding(.top,49)
        .backgroundBlur(radius: 20,opaque: true)
        .background(Color.navBarBackground)
        .frame(maxHeight:.infinity,alignment: .top)
        .ignoresSafeArea()
    }
}

struct NavBar_Previews: PreviewProvider {
    static var previews: some View {
        NavBar()
            .preferredColorScheme(.dark)
    }
}
