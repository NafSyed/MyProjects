# Weather


Weather is an iOS Application which is used to fetch and display the weather based on the location fetched from your device. It also consists of a seperate news section that is fetched from the SpaceNews API mostly (space and tech news).

### The frameworks used:
1. SwiftUI
2. CoreLocation
3. ActivityKit

After fetching of the current location from the device based on the latitude and longitude the app tries to connect with the OpenWeatherAPI to fetch the current weather based on the location. The main work happens in the Location Manager file to fetch the location and Weather Manager file to call the Weather API to get the weather.

Besides this WidgetKit is added to keep track of live activity to do a quick scan of the article based on a timer. ActivityKit is used to make the use of the Dynamic Island Feature.


