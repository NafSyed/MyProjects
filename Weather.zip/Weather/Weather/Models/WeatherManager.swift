//
//  WeatherManager.swift
//  Weather
//
//  Created by Nafeez Ahmed on 15/08/22.
//

import Foundation
import CoreLocation
import ActivityKit


class WeatherManager {
    // HTTP request to get the current weather depending on the coordinates we got from LocationManager
    func getCurrentWeather(latitude: CLLocationDegrees, longitude: CLLocationDegrees) async throws -> ResponseBody {
        // Replace YOUR_API_KEY in the link below with your own
        guard let url = URL(string: "https://api.openweathermap.org/data/2.5/weather?lat=\(latitude)&lon=\(longitude)&appid=\("edc91b7b06d2da65d1d3e65172479110")&units=metric") else { fatalError("Missing URL") }

// Makes request based on the URL
        let urlRequest = URLRequest(url: url)
        
        // Some Networking stuff here deals with the API call.
        let (data, response) = try await URLSession.shared.data(for: urlRequest)
        
        // Handling the errors in-case failure while fetching the data
        guard (response as? HTTPURLResponse)?.statusCode == 200 else { fatalError("Error while fetching data") }
        
        // Decoding the data according to the struct ResponseBody
        
        let decodedData = try JSONDecoder().decode(ResponseBody.self, from: data)
        
        return decodedData
    }
}

// Model of the response body we get from calling the OpenWeather API

struct ResponseBody: Codable, ActivityAttributes, Equatable {
    typealias ContentState = MainResponse
    var coord: CoordinatesResponse
    var weather: [WeatherResponse]
    var main: MainResponse
    var name: String
    var wind: WindResponse

    struct CoordinatesResponse: Codable,Hashable {
        var lon: Double
        var lat: Double
    }

    struct WeatherResponse: Codable, Hashable {
        var id: Double
        var main: String
        var description: String
        var icon: String
    }

    struct MainResponse: Codable, Hashable {
        var temp: Double
        var feels_like: Double
        var temp_min: Double
        var temp_max: Double
        var pressure: Double
        var humidity: Double
    }
    
    struct WindResponse: Codable, Hashable {
        var speed: Double
        var deg: Double
    }
    
    
}

extension ResponseBody.MainResponse {
    var feelsLike: Double { return feels_like }
    var tempMin: Double { return temp_min }
    var tempMax: Double { return temp_max }
}
