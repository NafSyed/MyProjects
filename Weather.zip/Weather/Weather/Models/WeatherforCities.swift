//
//  WeatherforCities.swift
//  Weather
//
//  Created by Nafeez Ahmed on 17/08/22.
//

import SwiftUI
import CoreLocation


struct Location: Identifiable {
    var id = UUID()
    var latitude: Double
    var longitude: Double
}

enum NetworkError: Error {
    case badURL
    case noData
    case custom(Error)
    case decodingError
    case badRequest
}


let locations: [Location] = [
    Location(latitude: 37.7749, longitude: -122.4194),
    Location(latitude: 43.651070, longitude: -79.347015),
    Location(latitude: 35.652832, longitude: 139.839478),
    Location(latitude: 40.730610, longitude: -73.935242)
]

class WeatherForCities {
    func getWeather(completion: @escaping (Result<ResponseBody1,NetworkError>)-> Void) {
        for location in locations {
            guard let url = URL(string: "https://api.openweathermap.org/data/2.5/weather?lat=\(location.latitude)&lon=\(location.longitude)&appid=\("edc91b7b06d2da65d1d3e65172479110")&units=metric")else {
                completion(.failure(.badURL))
                return
            }
            URLSession.shared.dataTask(with: url, completionHandler: {(data,response,error)in
                if let error = error {
                    completion(.failure(.custom(error)))
                }else if (response as? HTTPURLResponse)?.statusCode != 200 {
                    completion(.failure(.badRequest))
                }else {
                    guard let data = data else {
                        completion(.failure(.noData))
                        return
                    }
                    let weather = try? JSONDecoder().decode(ResponseBody1.self, from: data)
                    if let weather = weather {
                        completion(.success(weather))
                    }else {
                        completion(.failure(.decodingError))
                    }
                }
            }).resume()
        }
    }
}


struct ResponseBody1: Codable,  Equatable {
    typealias ContentState = MainResponse
    var coord: CoordinatesResponse
    var weather: [WeatherResponse]
    var main: MainResponse
    var name: String
    var wind: WindResponse

    struct CoordinatesResponse: Codable,Hashable {
        var lon: Double
        var lat: Double
    }

    struct WeatherResponse: Codable, Hashable {
        var id: Double
        var main: String
        var description: String
        var icon: String
    }

    struct MainResponse: Codable, Hashable {
        var temp: Double
        var feels_like: Double
        var temp_min: Double
        var temp_max: Double
        var pressure: Double
        var humidity: Double
    }
    
    struct WindResponse: Codable, Hashable {
        var speed: Double
        var deg: Double
    }
    
    
}

extension ResponseBody1.MainResponse {
    var feelsLike: Double { return feels_like }
    var tempMin: Double { return temp_min }
    var tempMax: Double { return temp_max }
}
