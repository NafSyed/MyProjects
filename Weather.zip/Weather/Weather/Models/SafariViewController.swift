//
//  SafariViewController.swift
//  Weather
//
//  Created by Nafeez Ahmed on 30/08/22.
//

import SwiftUI
import SafariServices


// the sheet of safari when the news is touched to read

struct SafariView: UIViewControllerRepresentable {
    let url: URL
    func makeUIViewController(context: Context) -> some SFSafariViewController {
        let safariVC = SFSafariViewController(url: url)
        return safariVC
    }
    func updateUIViewController(_ uiViewController: UIViewControllerType, context: Context) {}
}
