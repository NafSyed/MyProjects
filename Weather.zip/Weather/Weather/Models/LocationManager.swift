//
//  LocationManager.swift
//  Weather
//
//  Created by Nafeez Ahmed on 15/08/22.
//

import Foundation
import CoreLocation

class LocationManager: NSObject, ObservableObject, CLLocationManagerDelegate {
    // to fetch the current location based on the current latitude and longitude
    let manager = CLLocationManager()
    @Published var location: CLLocationCoordinate2D?
    @Published var isLoading = false
    
    override init() {
        super.init()
        manager.delegate = self
    }
    // Requesting location
    func requestLocation() {
        isLoading = true
        manager.requestLocation()
    }
    // Fetching the location
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        location = locations.first?.coordinate
        isLoading = false
    }
    // In-case we have to deal with the errors
    func locationManager(_ manager: CLLocationManager, didFailWithError error: Error) {
        print("Error getting location",error)
        isLoading = false
    }
}
