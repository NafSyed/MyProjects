//
//  NewsData.swift
//  Weather
//
//  Created by Nafeez Ahmed on 28/08/22.
//
 // API Response https://api.spaceflightnewsapi.net/v3/articles

import SwiftUI

typealias Articles = [Article]
struct Article: Codable, Identifiable {
    var id: Int
    var title: String
    var url: String
    var imageUrl: String
    var newsSite: String
    var summary: String
    var publishedAt: String
}
var artciles: [Article] = [
    Article(id: 0, title: "Hey Nafeez", url: "how are you", imageUrl: "sdsd", newsSite: "dfws", summary: "What are you doing", publishedAt: "dsd"),
    Article(id: 1, title: "Hey Fyzil", url: "how are you", imageUrl: "sdsd", newsSite: "dfws", summary: "What are you doing", publishedAt: "dsd"),
    Article(id: 2, title: "Hey Sameer", url: "how are you", imageUrl: "sdsd", newsSite: "dfws", summary: "What are you doing", publishedAt: "dsd"),
    Article(id: 3, title: "Hey Bruv", url: "how are you", imageUrl: "sdsd", newsSite: "dfws", summary: "What are you doing", publishedAt: "dsd"),
    Article(id: 4, title: "Hey Jaison", url: "how are you", imageUrl: "sdsd", newsSite: "dfws", summary: "What are you doing", publishedAt: "dsd"),
    Article(id: 5, title: "Hey Surya", url: "how are you", imageUrl: "sdsd", newsSite: "dfws", summary: "What are you doing", publishedAt: "dsd")
]
// The api used to fetch the news
@MainActor class API: ObservableObject {
    @Published var news: [Article] = []
    
    func getData() {
        guard let url = URL(string: "https://api.spaceflightnewsapi.net/v3/articles?_limit=15")else {
            return
        }
        URLSession.shared.dataTask(with: url) { data, response, error in
            guard let data = data else {
                let tempError = error?.localizedDescription
                DispatchQueue.main.async {
                    self.news = [Article(id: 0, title:tempError ?? "Error", url: "Error", imageUrl: "Error", newsSite: "Error", summary: "try swiping down to refresh as soon as you have internet!", publishedAt: "Error")]
                }
                return
            }
            let newsData = try! JSONDecoder().decode([Article].self, from: data)
            DispatchQueue.main.async {
                print("Loaded data successfully \(newsData.count)")
                self.news = newsData
            }
        }.resume()
    }
}

